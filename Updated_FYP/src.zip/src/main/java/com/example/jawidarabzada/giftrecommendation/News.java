package com.example.jawidarabzada.giftrecommendation;

/**
 * Created by JAWID ARABZADA on 1/4/2018.
 */




public class News {

    private String title;
    private String desc;
    private String image;
    private String url;
    private String price;

    public News(String title, String desc, String image, String url,String price) {
        this.title = title;
        this.desc = desc;
        this.image = image;
        this.url = url;
        this.price=price;
    }

    public News(){

    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }
}