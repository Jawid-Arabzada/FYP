package com.example.jawidarabzada.giftrecommendation;
//
//import android.content.Intent;
//import android.support.v7.app.AppCompatActivity;
//import android.os.Bundle;
//import android.view.Menu;
//import android.view.MenuItem;
//import android.view.View;
//import android.widget.Button;
//import android.widget.Toast;
//
//public class MainActivity extends AppCompatActivity {
//    private Button gift;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//
//        class fitIdeaButton implements View.OnClickListener{
//            public void onClick(View view) {
//                Intent giftpage = new Intent(MainActivity.this,Gift_Idea.class);
//                startActivity(giftpage);
//            }
//        }
//        gift = (Button)findViewById(R.id.btngift);
//        gift.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent giftpage = new Intent(MainActivity.this,Gift_Idea.class);
//                startActivity(giftpage);
//            }
//        });
//    }
//
//
//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        // Inflate the menu; this adds items to the action bar if it is present.
//        getMenuInflater().inflate(R.menu.drawermenu, menu);
//        return true;
//    }
//
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        // Handle action bar item clicks here. The action bar will
//        // automatically handle clicks on the Home/Up button, so long
//        // as you specify a parent activity in AndroidManifest.xml.
//        int id = item.getItemId();
//
//        //noinspection SimplifiableIfStatement
//        if (id == R.id.home1) {
//            Intent intent = new Intent(this,MainActivity.class);
//            this.startActivity(intent);
//            return true;
//        }
//
//        if (id == R.id.login) {
//
//            Intent intent = new Intent(this,Login.class);
//            this.startActivity(intent);
//            return true;
//        }
//
//        if (id == R.id.gidea) {
//            Intent intent = new Intent(this,Gift_Idea.class);
//            this.startActivity(intent);
//            return true;
//        }
//
//        if (id == R.id.event) {
//            Intent intent = new Intent(this,Reminder.class);
//            this.startActivity(intent);
//            return true;
//        }
//        if (id == R.id.feedback) {
//            Intent intent = new Intent(this,ContactActivity.class);
//            this.startActivity(intent);
//            return true;
//        }
//
//        return super.onOptionsItemSelected(item);
//    }
//}
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.github.clans.fab.FloatingActionButton;

public class MainActivity extends AppCompatActivity {

    private FloatingActionButton mFAB, mFab1,mFab2,mFab3,mFab4,mFab5,mFab6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mFAB = (FloatingActionButton) findViewById(R.id.menu_item6);
        mFab1 = (FloatingActionButton) findViewById(R.id.menu_item1);
        mFab2 = (FloatingActionButton) findViewById(R.id.menu_item2);
        mFab3 = (FloatingActionButton) findViewById(R.id.menu_item3);
        mFab4 = (FloatingActionButton) findViewById(R.id.menu_item4);
        mFab5 = (FloatingActionButton) findViewById(R.id.menu_item);



        mFAB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

               Intent intent = new Intent(MainActivity.this,Gift_Idea.class);
               startActivity(intent);
            }
        });

        mFab1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(MainActivity.this,Gift_Idea.class);
                startActivity(intent);
            }
        });

        mFab2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(MainActivity.this,Gift_Idea.class);
                startActivity(intent);
            }
        });

        mFab3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(MainActivity.this,Reminder.class);
                startActivity(intent);
            }
        });

        mFab4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(MainActivity.this,Gift_Idea.class);
                startActivity(intent);
            }
        });

        mFab5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(MainActivity.this,Gift_Idea.class);
                startActivity(intent);
            }
        });

    }
}