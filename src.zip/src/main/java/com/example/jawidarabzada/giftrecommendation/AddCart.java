package com.example.jawidarabzada.giftrecommendation;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class AddCart extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.product_list);
    }

    public void AddCart(View view)
    {
        Toast.makeText(this,"Added",Toast.LENGTH_LONG);
    }
}
